﻿using Microsoft.AspNetCore.Mvc;
using TestGenerator.Services;

namespace TestGenerator;

[ApiController]
[Route("[controller]")]
public class TestGeneratorController
{
    private readonly ITestGeneratorService testGeneratorService;

    public TestGeneratorController(
        ITestGeneratorService testGeneratorService
    )
    {
        this.testGeneratorService = testGeneratorService;
    }

    [HttpPost()]
    [Route("MakeTest")]
    public async Task<IActionResult> MakeTest(string code, string parameters)
    {
        var result = await testGeneratorService.MakeTest(code, parameters);

        return new OkObjectResult(result);
    }

    [HttpPost()]
    [Route("MakeTestForMethod")]
    public async Task<IActionResult> MakeTestForMethod(string code)
    {
        var result = await testGeneratorService.MakeTestForMethod(code);

        return new OkObjectResult(result);
    }
}
