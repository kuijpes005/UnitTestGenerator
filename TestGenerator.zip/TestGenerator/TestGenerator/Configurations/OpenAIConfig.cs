namespace TestGenerator.Configurations;

public class OpenAIConfig
{
    public string Key { get; set; } = "";
}