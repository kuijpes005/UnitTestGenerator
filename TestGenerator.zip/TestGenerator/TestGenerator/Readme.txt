Before using!

In appsettings.json, change the Key to the API key for OpenAI.


What
This is a unit test generator, with 2 different end points. 1 is for making a unit test, for one method exclusively. The other one is for writing test codes according to paremeters (e.g. writing an entire test class, etc.).

Why
When I first started using Chatgbt, I found that it was most useful writing unit tests. As it could write most of those tests the way I wanted it to, without too much editing. 

How
Place some code in the endpoint, and see you get a unit test back. When I first started using AI, I was mainly using MSTest, fluentAssertions and moq. Thus the unit tests should have those styles as well.