﻿namespace TestGenerator.Services;

public interface ITestGeneratorService
{
    Task<string> MakeTest(string code, string parameters);

    Task<string> MakeTestForMethod(string code);
}
