﻿namespace TestGenerator.Services;

using Microsoft.Extensions.Options;
using OpenAI_API.Chat;
using OpenAI_API.Models;
using TestGenerator.Configurations;

public class TestGeneratorService : ITestGeneratorService
{
    private readonly OpenAIConfig openAiConfig;

    private const string Context = "Write me a unit test for this method {0}. While doing this keep in mind the following {1}";

    private const string ContextForMethod = "using MSTest, fluentAssertions and using moq, a testclass has already been made and accounted for";

    public TestGeneratorService(IOptionsMonitor<OpenAIConfig> optionsMonitor)
    {
        openAiConfig = optionsMonitor.CurrentValue;
    }

    public async Task<string> MakeTest(string code, string parameters)
    {
        var prompt = string.Format(Context, code, parameters);

        return await GetResponseFromOpenAi(prompt);
    }

    public async Task<string> MakeTestForMethod(string code)
    {
        var prompt = string.Format(Context, code, ContextForMethod);

        return await GetResponseFromOpenAi(prompt);
    }

    private async Task<string> GetResponseFromOpenAi(string prompt)
    {
        var api = new OpenAI_API.OpenAIAPI(openAiConfig.Key);
        var result = await api.Chat.CreateChatCompletionAsync(new ChatRequest{
            Model = Model.ChatGPTTurbo,
            Temperature = 0.1,
            MaxTokens = 999,
            Messages = [
                new ChatMessage(ChatMessageRole.User, prompt)
            ]
        });
        return result.Choices[0].Message.TextContent;
    }
}
