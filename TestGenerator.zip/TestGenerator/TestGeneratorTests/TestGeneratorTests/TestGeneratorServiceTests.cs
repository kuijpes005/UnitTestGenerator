using FluentAssertions;
using Moq;
using TestGenerator.Services;
using OpenAI_API.Chat;
using TestGenerator.Configurations;
using Microsoft.Extensions.Options;
using OpenAI_API;

namespace TestGeneratorServiceTests
{
    [TestClass]
    public class TestGeneratorServiceTests
    {
        [TestMethod]
        public async Task MakeTestForMethod_ReturnsExpected()
        {
            /*
            // Unfortunately AI can't write all the unit tests correctly for you ;)
            // Arrange
            var code = "test code";
            var response = "test response";
            var testKey = "test key";
            var openAIConfig = new OpenAIConfig() { Key = testKey };
            var monitor = Mock.Of<IOptionsMonitor<OpenAIConfig>>(_ => _.CurrentValue == openAIConfig);

            var service = new TestGeneratorService(monitor);

            var mockApi = new Mock<IOpenAIAPI>();
            mockApi
                .Setup(api => api.Chat.CreateChatCompletionAsync(It.IsAny<ChatRequest>()))
                .ReturnsAsync(new ChatResult
                {
                    Choices = new List<ChatChoice>
                    {
                        new ChatChoice
                        {
                            Message = new ChatMessage
                            {
                                TextContent = response
                            }
                        }
                    }
                });


            // Act
            var result = await service.MakeTestForMethod(code);

            // Assert
            result.Should().Be(response);
            */
        }
    }
}