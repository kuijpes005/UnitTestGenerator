using FluentAssertions;
using Moq;
using Microsoft.AspNetCore.Mvc;
using TestGenerator.Services;
using TestGenerator;

namespace TestGeneratorTests
{
    [TestClass]
    public class TestControllerTests
    {
        [TestMethod]
        public async Task MakeTest_ReturnsExpected()
        {
            // Arrange
            var testGeneratorServiceMock = new Mock<ITestGeneratorService>();
            testGeneratorServiceMock
                .Setup(x => x.MakeTest(It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync("Unit test result");

            var controller = new TestGeneratorController(testGeneratorServiceMock.Object);

            // Act
            var result = await controller.MakeTest("Test Title", "Test Code") as OkObjectResult;

            // Assert
            result.Should().NotBeNull();
            result!.Value.Should().Be("Unit test result");
        }
    }
}